#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

int main() 
{
    int pipevar[2];
    char *message = "Hello from the first child!\n";
    char buffer[100];

    if (pipe(pipevar) == -1) 
    {
        perror("pipe");
        exit(1);
    }
    if (fork() == 0) // First child
    { 
        close(pipevar[0]); // Close read end
        write(pipevar[1], message, strlen(message)); // Write message length
        close(pipevar[1]); // Close write end

        exit(0);
    } 
    else if (fork() == 0) // Second child
    { 
        printf("Second child\n");
        close(pipevar[1]); // Close write end
        int nbytes = read(pipevar[0], buffer, sizeof(buffer)); // Read from pipe
        buffer[nbytes] = '\0'; // Null-terminate the string
        printf("%s", buffer); 
        close(pipevar[0]); // Close read end

        exit(0);
    } 
    else // Parent process
    { 
        close(pipevar[0]); // Parent closes both ends of the pipe
        close(pipevar[1]);
        wait(NULL); // Wait for both children
        wait(NULL);
    }

    return 0;
}