#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() 
{
    int x = 100;//Parent created value

    printf("parent pid:%d\n", (int) getpid());
    printf("Value shown and created in parent: x = %d\n",x);

    int rc = fork();
    if (rc < 0) // fork failed
    {
        fprintf(stderr, "fork failed\n");
        exit(1);
    } 
    else if (rc == 0)   // child (new process)
    {
        printf("child pid:%d\n", (int) getpid());
        printf("Value from parent shown in child: x = %d\n",x);
    }
    else 
    {
        wait(NULL);
        // parent continues process
        printf("parent of %d (parent pid:%d)\n",rc, (int) getpid());
        printf("x = %d\n", x);
    }

    return 0;
}